// Version 1: Create a program that counts by twos from 0 to 100. Display the numbers to the user in the browser.

// Version 2: Your product manager wants to increase user engagement by considering user input. Your product manager wants this program to be based on the user's range of minimum and maximum numbers. Display the numbers to the user in the browser.
// Example: Given a minimum of 5 and a maximum of 10, the browser will display: 6, 8, 10